'use client';

import { useEffect, useRef, useState } from 'react';
import styles from './ResourceGrid.module.css';
import BlogTabs from './BlogTabs';
import Pagination from './Pagination';

const PAGE_SIZE = 12;

function badgeClassName(mod) {
  return `${styles.badge} ${mod ? styles[mod] : ''}`;
}

export default function ResourceGrid({
  current,
  query,
  blogSub = 'all',
  onSelectSub,
  blogTabs = [],
  resources = [],
}) {
  const q = query.trim().toLowerCase();
  const sectionRef = useRef(null);

  // Numbered pages instead of "Load more" - matches the /blog page. Resets
  // to page 1 whenever the filter/search changes so you're not left on a
  // now out-of-range page.
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [current, query, blogSub]);

  const visible = resources.filter((r) => {
    // Media gets its own tab (MediaGrid) with a different card treatment -
    // it doesn't mix into "All".
    const categoryMatch = current === 'all' ? r.category !== 'media' : r.category === current;
    // when Blog is active, also honor the selected industry sub-tab
    const subMatch =
      current !== 'blog' || blogSub === 'all' || (r.subcats || []).includes(blogSub);
    const haystack = `${r.search} ${r.title} ${r.desc}`.toLowerCase();
    const searchMatch = !q || haystack.includes(q);
    return categoryMatch && subMatch && searchMatch;
  });

  // In "All", an article that belongs to two categories would otherwise
  // appear twice — de-duplicate by title. Lead with each category's own
  // latest item (so every tab is represented up front) then fall back to
  // everything else in date order - but only when browsing, not searching,
  // since a search should just show the best-matching results in order.
  const items = (() => {
    if (current !== 'all') return visible;
    const deduped = visible.filter((r, i, arr) => arr.findIndex((x) => x.title === r.title) === i);
    if (q) return deduped;

    const leaders = ['press', 'recognition', 'blog']
      .map((cat) => deduped.find((r) => r.category === cat))
      .filter(Boolean);
    const leaderTitles = new Set(leaders.map((r) => r.title));
    const rest = deduped.filter((r) => !leaderTitles.has(r.title));
    return [...leaders, ...rest];
  })();

  const totalPages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = items.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  function goToPage(next) {
    setPage(next);
    sectionRef.current?.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }

  // Square thumb (1:1) gives a clean, gap-free crop for every card. It's
  // used on the dedicated Blog tab (matches the /blog page) AND on "All",
  // since All mixes every category together and a single consistent thumb
  // shape keeps the grid aligned. The other single-category tabs (Press
  // Release, Recognition) keep the wider rectangular thumb.
  const useSquareThumb = current === 'blog' || current === 'all';

  return (
    <section className={styles.latest} id="latest" ref={sectionRef}>
      <div className={styles.container}>
        <div className={styles.sectionHead}>
          <div>
            <div className={styles.eyebrow}>Browse the hub</div>
            <h2>Latest resources</h2>
          </div>
        </div>

        {/* Blog is the one category with a second level of filtering. */}
        {current === 'blog' && (
          <BlogTabs active={blogSub} onSelect={onSelectSub} tabs={blogTabs} />
        )}

        {items.length > 0 ? (
          <>
            <div className={styles.grid}>
              {pageItems.map((r, i) => {
                const Wrapper = r.url ? 'a' : 'article';
                const linkProps = r.url
                  ? { href: r.url, ...(r.url.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {}) }
                  : {};
                return (
                  <Wrapper className={styles.card} key={`${r.category}-${r.title}-${i}`} {...linkProps}>
                    <div className={`${styles.thumb} ${r.category !== 'media' ? styles.thumbSquare : ''} ${r.image ? '' : styles[r.thumb]}`}>
                      {r.image ? (
                        <img className={styles.photo} src={r.image} alt={r.title} loading="lazy" decoding="async" />
                      ) : (
                        <>
                          <span className={`${styles.shape} ${styles.one}`} />
                          <span className={`${styles.shape} ${styles.two}`} />
                        </>
                      )}
                      {r.play && <span className={styles.play}>▶</span>}
                    </div>
                    <div className={styles.cardBody}>
                      <div className={styles.contentType}>{r.type}</div>
                      <span className={badgeClassName(r.badgeClass)}>{r.badge}</span>
                      <h3>{r.title}</h3>
                      <p>{r.desc}</p>
                      <div className={styles.cardFooter}>
                        <span>{r.meta}</span>
                        <span className={styles.read}>{r.action}</span>
                      </div>
                    </div>
                  </Wrapper>
                );
              })}
            </div>

            <Pagination currentPage={safePage} totalPages={totalPages} onPageChange={goToPage} />
          </>
        ) : (
          <div className={styles.empty}>No resources match your current search.</div>
        )}
      </div>
    </section>
  );
}