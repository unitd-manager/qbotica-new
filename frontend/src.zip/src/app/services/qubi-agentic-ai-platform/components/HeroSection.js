import { ArrowRight } from "lucide-react";
import Image from 'next/image';
import { ActionButton } from "./SharedComponents";

export function HeroSection({ data, heroSrc = "/assets/images/hero-illustration.jpg" }) {
  console.log('\n🎨 HeroSection received data:', data);

  const title = data?.title || "Orchestrate AI Agents, Bots, Systems & People with <span class=\"gradientText\">qubi</span>";
  const subTitle = data?.sub_title || "A unified platform for designing, deploying, and managing intelligent workflows powered by AI agents, automation, human input, and enterprise integrations.";
  const description = data?.description || "";
  const buttonText = data?.button_text || "Book a Demo";
  const buttonLink = data?.button_link?.url || "https://meetings.hubspot.com/automation-demo/scheduler";
  const image = data?.image?.url || heroSrc;

  return (
    <section className="heroSection">
      <div className="heroGlow" />
      <div className="pageContainer heroGrid">
        <div className="heroCopy">
          <div className="fadeUp">
            <span className="heroPill">
              <span className="heroPillDot" />
              {title}
            </span>
          </div>

          <h1 className="heroTitle fadeUp fadeUpDelay1" dangerouslySetInnerHTML={{ __html: subTitle }} />

          {description && (
            <p className="heroText fadeUp fadeUpDelay2" style={{ marginTop: '20px' }}>
              {description}
            </p>
          )}

          <div className="heroActions fadeUp fadeUpDelay3">
            <ActionButton href={buttonLink}>
              {buttonText}
              <ArrowRight size={18} />
            </ActionButton>
          </div>
        </div>

        <div className="heroVisual fadeUp fadeUpDelay2">
          <div className="heroFrame">
            <Image 
              src={image} 
              alt="qubi platform orchestration diagram" 
              className="heroImage"
              priority={true}
              width={800}
              height={600}
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 800px"
            />
            <div className="heroFrameRing" />
          </div>
        </div>
      </div>
    </section>
  );
}
